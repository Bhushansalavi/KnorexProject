## BACKEND

1 firstly you need to open  Mongodb
2 open Backend project and run command npm i 
3 run command npm start

## FRONTEND

1 Open Project and run command npm i 
2 run command npm start 