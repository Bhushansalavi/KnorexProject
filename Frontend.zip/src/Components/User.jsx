import axios from 'axios';
import React, { useEffect, useState } from 'react';

function User() {
  const [users, setUsers] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    retypedPassword: ""
  });

  const [modalInfo, setModalInfo] = useState({
    type: '', 
    message: '',
    userId: null 
  });

  const [showSuccessModal, setShowSuccessModal] = useState(false);

  function handlechange(e) {
    setData({ ...data, [e.target.id]: e.target.value });
  }

  const handlsubmit = () => {
    if (data.password !== data.retypedPassword) {
      alert("Passwords do not match!");
      return;
    }

    axios.post('http://localhost:8081/users', data)
      .then((res) => {
        console.log(res.data);
        setModalInfo({ type: 'success', message: 'Sign-up completed successfully!' })
        loaduserdata(); 
      })
      .catch((err) => {
        console.log(err);
      });
  };

   const handleDelete = (e, id) => {
    setModalInfo({ type: 'delete', message: 'Are you sure you want to delete this user?', userId: id });
  };
  const confirmDelete = () => {
    if (modalInfo.userId) {
      axios.delete("http://127.0.0.1:8081/users/" + modalInfo.userId)
        .then(() => {
            loaduserdata();
          setModalInfo({ type: '', message: '', userId: null }); 
        })
        .catch(err => console.log(err));
    }
  }

  const loaduserdata = () => {
    axios.get("http://localhost:8081/users")
      .then((res) => {
        setUsers(res.data.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    loaduserdata();
  }, []);

  const handleSelectAll = () => {
    if (selectedUsers.length === users.length) {
      setSelectedUsers([]); 
    } else {
      setSelectedUsers(users.map(user => user._id)); 
    }
  };

  const handleSelectUser = (userId) => {
    if (selectedUsers.includes(userId)) {
      setSelectedUsers(selectedUsers.filter(id => id !== userId)); 
    } else {
      setSelectedUsers([...selectedUsers, userId]); 
    }
  };

  const selectedUsersData = users.filter(user => selectedUsers.includes(user._id));

  // Function to export data to CSV
  const exportToCSV = () => {
    const csvData = selectedUsersData.map(user => ({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      password: user.password
    }));

    const csvHeaders = ['FirstName', 'LastName', 'Email', 'Password'];
    const csvRows = csvData.map(row => Object.values(row).join(',')).join('\n');
    
    const csvContent = `${csvHeaders.join(',')}\n${csvRows}`;
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'selected_users.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <div className='container mt-5'>
        <div className='card bg-light'>
          <div className='d-flex justify-content-between p-3' style={{ backgroundColor: '#435d7d' }}>
            <div>
              <h5 className='text-white'>Manage Users</h5>
            </div>
            <div>
              <button type="button" className="btn btn-primary justify-content-end me-3" data-bs-toggle="modal" data-bs-target="#exampleModal">
                SignUp
              </button>
              <button className="btn btn-success" onClick={exportToCSV}>
                Export Selected to CSV
              </button>
            </div>
          </div>

          <table id="user-table" className="table table-striped table-hover mt-3">
            <thead>
              <tr>
                <th scope="col">
                  <input
                    type="checkbox"
                    checked={selectedUsers.length === users.length && users.length > 0}
                    onChange={handleSelectAll}
                  />
                </th>
                <th scope="col">#</th>
                <th scope="col">FirstName</th>
                <th scope="col">Lastname</th>
                <th scope="col">Email</th>
                <th scope="col">Password</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user, index) => (
                <tr key={user._id}>
                  <th scope="col">
                    <input
                      type="checkbox"
                      checked={selectedUsers.includes(user._id)}
                      onChange={() => handleSelectUser(user._id)}
                    />
                  </th>
                  <th scope="row">{index + 1}</th>
                  <td>{user.firstName}</td>
                  <td>{user.lastName}</td>
                  <td>{user.email}</td>
                  <td>{user.password}</td>
                  <td>
                    <button className='btn btn-danger' onClick={(e) => handleDelete(e, user._id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

{/* Sign-up Modal */}
<div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title" id="exampleModalLabel">Sign Up Form</h5>
                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div className="modal-body">
                <div className="form-floating mb-3">
                  <input className="form-control" id="firstName" type="text" placeholder="firstName" onChange={handlechange} />
                  <label>FirstName</label>
                </div>
                <div className="form-floating mb-3">
                  <input className="form-control" id="lastName" type="text" placeholder="lastName" onChange={handlechange} />
                  <label>LastName</label>
                </div>
                <div className="form-floating mb-3">
                  <input className="form-control" id="email" type="email" placeholder="email" onChange={handlechange} />
                  <label>Email</label>
                </div>
                <div className="form-floating mb-3">
                  <input className="form-control" id="password" type="password" placeholder="password" onChange={handlechange} />
                  <label>Password</label>
                </div>
                <div className="form-floating mb-3">
                  <input className="form-control" id="retypedPassword" type="password" placeholder="retypedPassword" onChange={handlechange} />
                  <label>Re-Type Password</label>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">CANCEL</button>
                <button type="button" className="btn btn-primary" data-bs-dismiss="modal" onClick={handlsubmit}>SIGN UP</button>
              </div>
            </div>
          </div>
        </div>

 {/* Modal for success and delete confirmation */}
 <div className={`modal fade ${modalInfo.type ? 'show' : ''}`} style={{ display: modalInfo.type ? 'block' : 'none' }} tabIndex="-1" aria-hidden={!modalInfo.type}>
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{modalInfo.type === 'success' ? 'Success' : 'Confirm Delete'}</h5>
                <button type="button" className="btn-close" onClick={() => setModalInfo({ type: '', message: '', userId: null })}></button>
              </div>
              <div className="modal-body">
                <p>{modalInfo.type === 'success' ? modalInfo.message : modalInfo.message}</p>
              </div>
              <div className="modal-footer">
                {modalInfo.type === 'success' ? (
                  <button type="button" className="btn btn-primary" onClick={() => setModalInfo({ type: '', message: '', userId: null })}>Close</button>
                ) : (
                  <>
                    <button type="button" className="btn btn-secondary" onClick={() => setModalInfo({ type: '', message: '', userId: null })}>Cancel</button>
                    <button type="button" className="btn btn-danger" onClick={confirmDelete}>Delete</button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>


      </div>
    </>
  );
}

export default User;
