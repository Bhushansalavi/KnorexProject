import './App.css';
import User from './Components/User';

function App() {
  return (
    <>
    <User/>
    </>
  );
}

export default App;
