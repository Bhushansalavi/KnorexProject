let mongoose = require("mongoose");
let Schema = mongoose.Schema;

let userSchema = new Schema({
    deleted: { type: Boolean },
    email: { type: String },
    firstName: { type: String },
    lastName: { type: String },
    password: { type: String }
});



let User = mongoose.model("users", userSchema);
module.exports = User;
